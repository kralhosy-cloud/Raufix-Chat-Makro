package dev.chatmacro.studio.client.screen;

import dev.chatmacro.studio.ModInfo;
import dev.chatmacro.studio.client.ProfileTransfer;
import dev.chatmacro.studio.theme.ThemeTokens;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Lists the ".cmsprofile" files in {@code config/chatmacro_studio/exports/} so
 * the user can pick one to import.
 *
 * <p>There is no free-form path entry on purpose: the only files this mod will
 * read are the ones in its own exports directory, and the resolved path is
 * checked against that directory before it is opened.</p>
 */
public final class BundlePickerScreen extends class_437 {

    private static final int ROW_HEIGHT = 14;

    private final ProfileTransfer transfer;
    private final ThemeTokens tokens;
    private final java.util.function.Consumer<String> onChosen;
    private final Runnable onCancel;

    private final List<String> names;
    private int selected;
    private int scroll;

    public BundlePickerScreen(ProfileTransfer transfer, ThemeTokens tokens,
                              java.util.function.Consumer<String> onChosen, Runnable onCancel) {
        super(class_2561.method_43471(ModInfo.tr("import.pickTitle")));
        this.transfer = transfer;
        this.tokens = tokens;
        this.onChosen = onChosen;
        this.onCancel = onCancel;
        this.names = transfer.availableBundles();
    }

    @Override
    protected void method_25426() {
        method_37067();
        int buttonWidth = 90;
        int left = (this.field_22789 - buttonWidth * 2 - 8) / 2;
        int y = this.field_22790 - 32;
        method_37063(class_4185
                .method_46430(class_2561.method_43471(ModInfo.tr("import.preview")), b -> choose())
                .method_46434(left, y, buttonWidth, 20).method_46431());
        method_37063(class_4185
                .method_46430(class_2561.method_43471(ModInfo.tr("action.cancel")), b -> method_25419())
                .method_46434(left + buttonWidth + 8, y, buttonWidth, 20).method_46431());
    }

    private void choose() {
        if (selected < 0 || selected >= names.size()) return;
        onChosen.accept(names.get(selected));
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_25294(0, 0, this.field_22789, this.field_22790, tokens.background());

        int pad = 14;
        int y = pad;
        ctx.method_25303(field_22793,
                class_2561.method_43471(ModInfo.tr("import.pickTitle")).getString(), pad, y, tokens.normalText());
        y += 16;

        if (names.isEmpty()) {
            ctx.method_25303(field_22793,
                    class_2561.method_43471(ModInfo.tr("import.noneFound")).getString(), pad, y, tokens.mutedText());
            super.method_25394(ctx, mouseX, mouseY, delta);
            return;
        }

        int listTop = y;
        int listHeight = Math.max(ROW_HEIGHT, this.field_22790 - listTop - 44);
        StudioPalette.panel(ctx, pad - 4, listTop - 4, this.field_22789 - pad * 2 + 8, listHeight + 8,
                tokens.backgroundAlt(), tokens.border(), tokens.background());
        ctx.method_44379(pad - 3, listTop - 3, this.field_22789 - pad + 3, listTop + listHeight + 3);
        for (int i = 0; i < names.size(); i++) {
            int rowY = listTop + i * ROW_HEIGHT - scroll;
            if (rowY < listTop - ROW_HEIGHT || rowY > listTop + listHeight) continue;
            if (i == selected) {
                ctx.method_25294(pad, rowY - 2, this.field_22789 - pad, rowY + ROW_HEIGHT - 3, tokens.raisedPanel());
                ctx.method_25294(pad, rowY - 2, pad + 2, rowY + ROW_HEIGHT - 3, tokens.accent());
            }
            ctx.method_25303(field_22793,
                    StudioPalette.ellipsize(field_22793, names.get(i), this.field_22789 - pad * 2 - 8),
                    pad + 8, rowY, i == selected ? tokens.normalText() : tokens.mutedText());
        }
        ctx.method_44380();

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int pad = 14;
        int listTop = pad + 16;
        int index = (int) ((mouseY - listTop + scroll) / ROW_HEIGHT);
        if (mouseX >= pad && mouseX <= this.field_22789 - pad && index >= 0 && index < names.size()) {
            selected = index;
            return true;
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int previous = scroll;
        scroll = Math.max(0, scroll - (int) Math.signum(verticalAmount) * ROW_HEIGHT * 2);
        return scroll != previous || super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25404(class_11908 input) {
        int keyCode = input.comp_4795();
        if (keyCode == 264 && selected < names.size() - 1) { selected++; return true; }
        if (keyCode == 265 && selected > 0) { selected--; return true; }
        return super.method_25404(input);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        super.method_25419();
        onCancel.run();
    }
}
