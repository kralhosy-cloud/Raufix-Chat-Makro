package dev.chatmacro.studio.client.screen;

import dev.chatmacro.studio.ModInfo;
import dev.chatmacro.studio.theme.ThemeTokens;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * A small confirmation dialog used for destructive actions (delete profile,
 * delete macro, discard unsaved edits) and for the first run of a command macro
 * that could move money or items.
 *
 * <p>Escape cancels. Enter confirms. The destructive button is red and the safe
 * button keeps the default styling, and both are reachable with Tab.</p>
 */
public final class ConfirmDialogScreen extends class_437 {

    private final String titleKey;
    private final String bodyKey;
    private final Object[] bodyArgs;
    private final String confirmKey;
    private final boolean dangerous;
    private final Runnable onConfirm;
    private final Runnable onClose;
    private final ThemeTokens tokens;

    /**
     * @param onConfirm runs when the user confirms
     * @param onClose   runs on every exit path (confirm, cancel and Escape) so
     *                  the caller can put its own screen back
     */
    public ConfirmDialogScreen(String titleKey, String bodyKey, Object[] bodyArgs, String confirmKey,
                               boolean dangerous, ThemeTokens tokens, Runnable onConfirm, Runnable onClose) {
        super(class_2561.method_43471(ModInfo.tr(titleKey)));
        this.titleKey = titleKey;
        this.bodyKey = bodyKey;
        this.bodyArgs = bodyArgs == null ? new Object[0] : bodyArgs;
        this.confirmKey = confirmKey;
        this.dangerous = dangerous;
        this.tokens = tokens;
        this.onConfirm = onConfirm;
        this.onClose = onClose == null ? () -> { } : onClose;
    }

    @Override
    protected void method_25426() {
        int panelWidth = Math.min(260, this.field_22789 - 40);
        int panelX = (this.field_22789 - panelWidth) / 2;
        int buttonWidth = (panelWidth - 30) / 2;
        int buttonY = this.field_22790 / 2 + 24;

        method_37063(class_4185.method_46430(class_2561.method_43471(ModInfo.tr(confirmKey)), b -> {
                    onConfirm.run();
                    method_25419();
                })
                .method_46434(panelX + 10, buttonY, buttonWidth, 20)
                .method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471(ModInfo.tr("action.cancel")), b -> method_25419())
                .method_46434(panelX + 20 + buttonWidth, buttonY, buttonWidth, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        super.method_25394(ctx, mouseX, mouseY, delta);
        int panelWidth = Math.min(260, this.field_22789 - 40);
        int panelHeight = 86;
        int panelX = (this.field_22789 - panelWidth) / 2;
        int panelY = this.field_22790 / 2 - panelHeight / 2;

        StudioPalette.shadow(ctx, panelX, panelY, panelWidth, panelHeight, tokens.shadow());
        StudioPalette.panel(ctx, panelX, panelY, panelWidth, panelHeight,
                tokens.raisedPanel(), tokens.borderStrong(), 0);

        String title = class_2561.method_43471(ModInfo.tr(titleKey)).getString();
        ctx.method_25303(field_22793, title, panelX + 12, panelY + 10, tokens.normalText());

        String body = class_2561.method_43469(ModInfo.tr(bodyKey), bodyArgs).getString();
        int lineY = panelY + 26;
        for (String line : wrap(body, panelWidth - 24)) {
            ctx.method_25303(field_22793, line, panelX + 12, lineY, tokens.mutedText());
            lineY += 11;
        }
    }

    @Override
    public boolean method_25421() {
        // A dialog must not pause the game in multiplayer, and pausing in single
        // player would freeze the very scheduler the dialog is asking about.
        return false;
    }

    @Override
    public void method_25419() {
        super.method_25419();
        onClose.run();
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == 256) {                 // Escape
            method_25419();
            return true;
        }
        return super.method_25404(input);
    }

    /** Tiny greedy wrapper; the dialog only ever shows a sentence or two. */
    private java.util.List<String> wrap(String value, int maxWidth) {
        java.util.List<String> lines = new java.util.ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (String word : value.split(" ")) {
            String candidate = current.length() == 0 ? word : current + " " + word;
            if (field_22793.method_1727(candidate) > maxWidth && current.length() > 0) {
                lines.add(current.toString());
                current.setLength(0);
                current.append(word);
            } else {
                current.setLength(0);
                current.append(candidate);
            }
        }
        if (current.length() > 0) lines.add(current.toString());
        return lines;
    }

    /** Exposed so the studio can style the dialog to match its own palette. */
    public boolean isDangerous() {
        return dangerous;
    }
}
