package dev.chatmacro.studio.client.screen;

import dev.chatmacro.studio.ModInfo;
import dev.chatmacro.studio.Studio;
import dev.chatmacro.studio.io.ProfileBundle;
import dev.chatmacro.studio.model.Profile;
import dev.chatmacro.studio.repo.RepoResult;
import dev.chatmacro.studio.theme.ThemeTokens;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Shows what an import would do, before it does it.
 *
 * <p>The preview lists the profile name, description, scope and every macro that
 * would be created, and flags sensitive or secret content. Nothing is written
 * until the user presses import; imported macros are always disabled and always
 * get new UUIDs, and overwriting an existing profile needs a separate
 * confirmation inside {@code StudioScreen}.</p>
 */
public final class ImportPreviewScreen extends class_437 {

    private final ProfileBundle.Preview preview;
    private final String json;
    private final ThemeTokens tokens;
    private final Studio studio;
    private final Runnable onImported;

    private int scroll;
    private String statusKey = "";
    private class_4185 importButton;

    public ImportPreviewScreen(ProfileBundle.Preview preview, String json, ThemeTokens tokens,
                               Studio studio, Runnable onImported) {
        super(class_2561.method_43471(ModInfo.tr("import.previewTitle")));
        this.preview = preview;
        this.json = json;
        this.tokens = tokens;
        this.studio = studio;
        this.onImported = onImported;
    }

    @Override
    protected void method_25426() {
        method_37067();
        int buttonWidth = 90;
        int left = (this.field_22789 - buttonWidth * 2 - 8) / 2;
        int y = this.field_22790 - 32;
        importButton = method_37063(class_4185
                .method_46430(class_2561.method_43471(ModInfo.tr("import.confirm")), b -> performImport())
                .method_46434(left, y, buttonWidth, 20).method_46431());
        method_37063(class_4185
                .method_46430(class_2561.method_43471(ModInfo.tr("action.cancel")), b -> method_25419())
                .method_46434(left + buttonWidth + 8, y, buttonWidth, 20).method_46431());
    }

    private void performImport() {
        if (importButton != null) importButton.field_22763 = false;
        // Overwrite is false: a name collision is reported instead of replacing
        // anything. The caller decides what to do with that answer.
        try {
            ProfileBundle.Preview fresh = studio.bundles().preview(json);
            RepoResult<Profile> result = studio.importProfile(fresh, false);
            if (!result.success()) {
                setStatus(result.messageKeyOrEmpty());
                if (importButton != null) importButton.field_22763 = true;
                return;
            }
            onImported.run();
            method_25419();
        } catch (dev.chatmacro.studio.config.ConfigException e) {
            setStatus("import.invalid");
            if (importButton != null) importButton.field_22763 = true;
        }
    }

    private void setStatus(String key) {
        this.statusKey = key == null ? "" : key;
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_25294(0, 0, this.field_22789, this.field_22790, tokens.background());
        int pad = 14;
        int lineH = 11;
        int y = pad;

        ctx.method_25303(field_22793,
                class_2561.method_43471(ModInfo.tr("import.previewTitle")).getString(),
                pad, y, tokens.normalText());
        y += lineH + 4;

        List<String> lines = describe();
        ctx.method_44379(pad - 4, y - 2, this.field_22789 - pad + 4, this.field_22790 - 44);
        for (int i = 0; i < lines.size(); i++) {
            int lineY = y + i * lineH - scroll;
            if (lineY < y - lineH || lineY > this.field_22790 - 44) continue;
            String line = lines.get(i);
            int color = line.startsWith("!") ? tokens.danger() : tokens.mutedText();
            String text = line.startsWith("!") ? line.substring(1) : line;
            ctx.method_25303(field_22793,
                    StudioPalette.ellipsize(field_22793, text, this.field_22789 - pad * 2), pad, lineY, color);
        }
        ctx.method_44380();

        if (!statusKey.isEmpty()) {
            ctx.method_25303(field_22793,
                    StudioPalette.ellipsize(field_22793,
                            class_2561.method_43471(ModInfo.tr(statusKey)).getString(), this.field_22789 - pad * 2),
                    pad, this.field_22790 - 46, tokens.danger());
        }

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    private List<String> describe() {
        ProfileBundle.BundleProfile p = preview.profile();
        java.util.List<String> out = new java.util.ArrayList<>();
        out.add(class_2561.method_43469(ModInfo.tr("import.name"), p.name()).getString());
        if (!p.description().isEmpty()) {
            out.add(class_2561.method_43469(ModInfo.tr("import.description"), p.description()).getString());
        }
        out.add(class_2561.method_43471(ModInfo.tr(p.scope().describeKey())).getString());
        out.add(class_2561.method_43469(ModInfo.tr("import.macroCount"), p.macros().size()).getString());
        for (ProfileBundle.BundleMacro macro : p.macros()) {
            out.add("  " + class_2561.method_43469(ModInfo.tr("import.macroLine"), macro.name(),
                    class_2561.method_43471(ModInfo.tr(macro.type() == dev.chatmacro.studio.model.MacroContentType.COMMAND
                            ? "macro.type.command" : "macro.type.chat")).getString(),
                    macro.intervalSeconds()).getString());
        }
        out.add("");
        out.add(class_2561.method_43471(ModInfo.tr("import.alwaysDisabled")).getString());
        if (preview.containsSensitive()) {
            out.add("!" + class_2561.method_43471(ModInfo.tr("import.containsSensitive")).getString());
        }
        if (preview.containsSecrets()) {
            out.add("!" + class_2561.method_43471(ModInfo.tr("import.containsSecrets")).getString());
        }
        for (String problem : preview.problems()) {
            out.add("!" + class_2561.method_43471(ModInfo.tr(problem)).getString());
        }
        return out;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int previous = scroll;
        scroll = Math.max(0, scroll - (int) Math.signum(verticalAmount) * 22);
        return scroll != previous || super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
