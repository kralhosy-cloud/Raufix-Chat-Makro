package dev.chatmacro.studio.client.screen;

import dev.chatmacro.studio.ModInfo;
import dev.chatmacro.studio.Studio;
import dev.chatmacro.studio.theme.ThemeTokens;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Shows the local diagnostics the mod is willing to share, exactly as they will
 * appear if the user copies them.
 *
 * <p>The content comes from {@link Studio#diagnostics()}, which already masks
 * the server address and never contains message bodies. This screen previews
 * that text; it does not send it anywhere, and there is no "send" button.</p>
 */
public final class DiagnosticsScreen extends class_437 {

    private final ThemeTokens tokens;
    private final List<String> lines;
    private final Runnable onClose;

    private int scroll;

    public DiagnosticsScreen(Studio studio, ThemeTokens tokens, Runnable onClose) {
        super(class_2561.method_43471(ModInfo.tr("diagnostics.title")));
        this.tokens = tokens;
        this.lines = studio.diagnostics();
        this.onClose = onClose;
    }

    @Override
    protected void method_25426() {
        method_37067();
        method_37063(class_4185
                .method_46430(class_2561.method_43471(ModInfo.tr("action.close")), b -> method_25419())
                .method_46434((this.field_22789 - 90) / 2, this.field_22790 - 32, 90, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_25294(0, 0, this.field_22789, this.field_22790, tokens.background());

        int pad = 14;
        ctx.method_25303(field_22793,
                class_2561.method_43471(ModInfo.tr("diagnostics.title")).getString(),
                pad, pad, tokens.normalText());
        int y = pad + 14;
        ctx.method_25303(field_22793,
                class_2561.method_43471(ModInfo.tr("diagnostics.explainer")).getString(),
                pad, y, tokens.mutedText());
        y += 18;

        ctx.method_44379(pad - 4, y - 2, this.field_22789 - pad + 4, this.field_22790 - 44);
        for (int i = 0; i < lines.size(); i++) {
            int lineY = y + i * 11 - scroll;
            if (lineY < y - 11 || lineY > this.field_22790 - 44) continue;
            ctx.method_25303(field_22793,
                    StudioPalette.ellipsize(field_22793, lines.get(i), this.field_22789 - pad * 2),
                    pad, lineY, tokens.normalText());
        }
        ctx.method_44380();

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int previous = scroll;
        scroll = Math.max(0, scroll - (int) Math.signum(verticalAmount) * 22);
        return scroll != previous || super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        super.method_25419();
        onClose.run();
    }
}
