package dev.chatmacro.studio.client;

import dev.chatmacro.studio.ModInfo;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Key bindings.
 *
 * <p><b>About "F30":</b> GLFW defines physical function keys only up to
 * {@code F25}; there is no {@code GLFW_KEY_F30} and this mod does not invent one.
 * "F30" survives only as a user-facing label for the <em>action</em> "open the
 * studio", plus the {@code /chatmacro f30} command alias. If a keyboard or a
 * macro pad exposes an F30 button, the player maps it to this binding in
 * Minecraft's Controls screen like any other key. The default is Right Shift.</p>
 *
 * <p>Both bindings are reassignable from Controls and live in their own category
 * so they are easy to find.</p>
 */
public final class StudioKeyBindings {

    /** Controls-screen category; localised by both language files. */
    public static final String CATEGORY_KEY = ModInfo.tr("key.category");

    /**
     * 1.21.11 replaced the category <em>string</em> with a
     * {@link class_304.class_11900} record wrapping an {@link class_2960}. The
     * identifier doubles as the translation key for the category label, so the
     * localised key is wrapped as-is.
     */
    public static final class_304.class_11900 CATEGORY =
            class_304.class_11900.method_74698(class_2960.method_60655(ModInfo.MOD_ID, "studio"));

    // Both fields are public non-final statics, which the project's Semgrep
    // ruleset flags. Accepted deliberately: this is the documented Fabric key
    // binding pattern, they are assigned exactly once in register() before any
    // tick handler can read them, and nothing else writes to them.
    /** Opens the studio. Logical alias: "F30". */
    public static class_304 openStudio; // nosemgrep: cms-public-mutable-static

    /** Emergency stop: cancels the run immediately, wherever the player is. */
    public static class_304 emergencyStop; // nosemgrep: cms-public-mutable-static

    private StudioKeyBindings() {
    }

    public static void register() {
        // KeyBinding's constructor now takes a translation key, not a Text.
        openStudio = KeyBindingHelper.registerKeyBinding(new class_304(
                ModInfo.tr("key.openStudio"),
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                CATEGORY));

        emergencyStop = KeyBindingHelper.registerKeyBinding(new class_304(
                ModInfo.tr("key.emergencyStop"),
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_CONTROL,
                CATEGORY));
    }
}
